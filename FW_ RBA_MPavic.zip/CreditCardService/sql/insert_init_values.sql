INSERT INTO credit_card_status_type (name) VALUES ('Approved'), ('Rejected'), ('Pending');

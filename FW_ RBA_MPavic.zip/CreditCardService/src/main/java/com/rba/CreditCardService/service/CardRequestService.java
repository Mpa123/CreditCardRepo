package com.rba.CreditCardService.service;

import com.rba.CreditCardService.model.User;

public interface CardRequestService {

    void forwardClientDetails(User user);
}

package com.rba.CreditCardService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditCardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
